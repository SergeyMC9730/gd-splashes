Big Toilet sprite was made by Toby Fox
All sprites used for GDPS Tools Buttons was made by Robert Topala for Geometry Dash.